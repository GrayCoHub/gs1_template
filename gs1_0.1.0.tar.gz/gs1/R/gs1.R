#' Title
#'
#' @param x
#'
#' @return The output for code{\link{print}
#' @export gs1
#'
#' @examples
#' gs1(1)
#' gs1(a string)
#gs1(3. str(df))
#gs1(Output from attributes(df))
